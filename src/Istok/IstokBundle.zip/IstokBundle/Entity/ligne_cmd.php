<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ligne_cmd
 *
 * @ORM\Table(name="ligne_cmd")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\ligne_cmdRepository")
 */
class ligne_cmd
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="quantite", type="integer")
     */
    private $quantite;

    /**
     * @var string
     *
     * @ORM\Column(name="idcmd", type="string", length=50)
     */
    private $idcmd;


    /**
     * @var float
     *
     * @ORM\Column(name="prix", type="float")
     */
    private $prix;

    /**
     * @var float
     *
     * @ORM\Column(name="total", type="float")
     */
    private $total;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime")
     */
    private $date;


    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;
    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\vente")
    *@ORM\JoinColumn(name="vente_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $vente;

    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\article")
    *@ORM\JoinColumn(name="article_id",referencedColumnName="id")
    */
    private $article;


    /**
    *@ORM\ManyToOne(targetEntity="\User\UserBundle\Entity\user")
    *@ORM\JoinColumn(name="user_id",referencedColumnName="id")
    */
    private $user;

    
    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set quantite
     *
     * @param integer $quantite
     *
     * @return ligne_cmd
     */
    public function setQuantite($quantite)
    {
        $this->quantite = $quantite;

        return $this;
    }

    /**
     * Get quantite
     *
     * @return int
     */
    public function getQuantite()
    {
        return $this->quantite;
    }

    /**
     * Set prix
     *
     * @param float $prix
     *
     * @return ligne_cmd
     */
    public function setPrix($prix)
    {
        $this->prix = $prix;

        return $this;
    }

    /**
     * Get prix
     *
     * @return float
     */
    public function getPrix()
    {
        return $this->prix;
    }

    /**
     * Set total
     *
     * @param float $total
     *
     * @return ligne_cmd
     */
    public function setTotal($total)
    {
        $this->total = $total;

        return $this;
    }

    /**
     * Get total
     *
     * @return float
     */
    public function getTotal()
    {
        return $this->total;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     *
     * @return ligne_cmd
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set vente
     *
     * @param \Istok\IstokBundle\Entity\vente $vente
     *
     * @return ligne_cmd
     */
    public function setVente(\Istok\IstokBundle\Entity\vente $vente = null)
    {
        $this->vente = $vente;

        return $this;
    }

    /**
     * Get vente
     *
     * @return \Istok\IstokBundle\Entity\vente
     */
    public function getVente()
    {
        return $this->vente;
    }

    /**
     * Set article
     *
     * @param \Istok\IstokBundle\Entity\article $article
     *
     * @return ligne_cmd
     */
    public function setArticle(\Istok\IstokBundle\Entity\article $article = null)
    {
        $this->article = $article;

        return $this;
    }

    /**
     * Get article
     *
     * @return \Istok\IstokBundle\Entity\article
     */
    public function getArticle()
    {
        return $this->article;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return ligne_cmd
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }

  
  

    /**
     * Set idcmd
     *
     * @param string $idcmd
     *
     * @return ligne_cmd
     */
    public function setIdcmd($idcmd)
    {
        $this->idcmd = $idcmd;

        return $this;
    }

    /**
     * Get idcmd
     *
     * @return string
     */
    public function getIdcmd()
    {
        return $this->idcmd;
    }

    /**
     * Set user
     *
     * @param \User\UserBundle\Entity\user $user
     *
     * @return ligne_cmd
     */
    public function setUser(\User\UserBundle\Entity\user $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \User\UserBundle\Entity\user
     */
    public function getUser()
    {
        return $this->user;
    }
}
