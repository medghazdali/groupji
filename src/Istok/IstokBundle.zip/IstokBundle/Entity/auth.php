<?php

namespace Istok\IstokBundle\Helper;

class auth {

    private $entityManager;

    public function __construct(EntityManager $entityManager) {
        $this->entityManager = $entityManager;
    }

    public function get_identity() {
        
        return 45;
    }
}