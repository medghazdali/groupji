<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * client
 *
 * @ORM\Table(name="client")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\clientRepository")
 */
class client
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=50)
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="prenom", type="string", length=50)
     */
    private $prenom;

    /**
     * @var string
     *
     * @ORM\Column(name="tel", type="string", length=50)
     */
    private $tel;

    /**
     * @var string
     *
     * @ORM\Column(name="cin", type="string", length=50)
     */
    private $cin;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime")
     */
    private $date;


    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;

    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\type")
    *@ORM\JoinColumn(name="type_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $type;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return client
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set prenom
     *
     * @param string $prenom
     *
     * @return client
     */
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;

        return $this;
    }

    /**
     * Get prenom
     *
     * @return string
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * Set tel
     *
     * @param string $tel
     *
     * @return client
     */
    public function setTel($tel)
    {
        $this->tel = $tel;

        return $this;
    }

    /**
     * Get tel
     *
     * @return string
     */
    public function getTel()
    {
        return $this->tel;
    }

    /**
     * Set cin
     *
     * @param string $cin
     *
     * @return client
     */
    public function setCin($cin)
    {
        $this->cin = $cin;

        return $this;
    }

    /**
     * Get cin
     *
     * @return string
     */
    public function getCin()
    {
        return $this->cin;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     *
     * @return client
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set reference
     *
     * @param string $reference
     *
     * @return client
     */
    public function setReference($reference)
    {
        $this->reference = $reference;

        return $this;
    }

    /**
     * Get reference
     *
     * @return string
     */
    public function getReference()
    {
        return $this->reference;
    }

    /**
     * Set categories
     *
     * @param \Istok\IstokBundle\Entity\type $categories
     *
     * @return client
     */
    public function setCategories(\Istok\IstokBundle\Entity\type $categories = null)
    {
        $this->categories = $categories;

        return $this;
    }

    /**
     * Get categories
     *
     * @return \Istok\IstokBundle\Entity\type
     */
    public function getCategories()
    {
        return $this->categories;
    }

    /**
     * Set type
     *
     * @param \Istok\IstokBundle\Entity\type $type
     *
     * @return client
     */
    public function setType(\Istok\IstokBundle\Entity\type $type = null)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \Istok\IstokBundle\Entity\type
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return client
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }
}
