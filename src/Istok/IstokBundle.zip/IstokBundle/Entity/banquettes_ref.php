<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * banquettes_ref
 *
 * @ORM\Table(name="banquettes_ref")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\banquettesRepository")
 */
class banquettes_ref
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="prix", type="float", length=50)
     */
    private $prix;


    /**
     * @var string
     *
     * @ORM\Column(name="reference", type="string", length=50)
     */
    private $reference;


    
    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;


    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\sous_banquettes")
    *@ORM\JoinColumn(name="sous_banquettes_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $sous_banquettes;
   



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set prix
     *
     * @param float $prix
     *
     * @return banquettes_ref
     */
    public function setPrix($prix)
    {
        $this->prix = $prix;

        return $this;
    }

    /**
     * Get prix
     *
     * @return float
     */
    public function getPrix()
    {
        return $this->prix;
    }

    /**
     * Set reference
     *
     * @param string $reference
     *
     * @return banquettes_ref
     */
    public function setReference($reference)
    {
        $this->reference = $reference;

        return $this;
    }

    /**
     * Get reference
     *
     * @return string
     */
    public function getReference()
    {
        return $this->reference;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return banquettes_ref
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }

    /**
     * Set sousBanquettes
     *
     * @param \Istok\IstokBundle\Entity\sous_banquettes $sousBanquettes
     *
     * @return banquettes_ref
     */
    public function setSousBanquettes(\Istok\IstokBundle\Entity\sous_banquettes $sousBanquettes = null)
    {
        $this->sous_banquettes = $sousBanquettes;

        return $this;
    }

    /**
     * Get sousBanquettes
     *
     * @return \Istok\IstokBundle\Entity\sous_banquettes
     */
    public function getSousBanquettes()
    {
        return $this->sous_banquettes;
    }
}
