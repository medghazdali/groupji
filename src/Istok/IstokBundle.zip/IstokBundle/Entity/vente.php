<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * vente
 *
 * @ORM\Table(name="vente")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\venteRepository")
 */
class vente
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="num", type="integer")
     */
    private $num;

    /**
     * @var int
     *
     * @ORM\Column(name="isavance", type="integer")
     */
    private $isavance;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime")
     */
    private $date;

    /**
     * @var string
     *
     * @ORM\Column(name="remarque", type="string", length=255, nullable=true)
     */
    private $remarque;

    /**
     * @var float
     *
     * @ORM\Column(name="total", type="float")
     */
    private $total;

    /**
     * @var float
     *
     * @ORM\Column(name="avance", type="float")
     */
    private $avance;

    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\client")
    *@ORM\JoinColumn(name="client_id",referencedColumnName="id")
    */
    private $client;

    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\facilite")
    *@ORM\JoinColumn(name="facilite_id",referencedColumnName="id")
    */
    private $facilite;


    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;


    /**
     * @var string
     *
     * @ORM\Column(name="type", type="integer")
     */
    private $type=0;



    /**
    *@ORM\ManyToOne(targetEntity="\User\UserBundle\Entity\user")
    *@ORM\JoinColumn(name="user_id",referencedColumnName="id")
    */
    private $user;

    

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set num
     *
     * @param integer $num
     *
     * @return vente
     */
    public function setNum($num)
    {
        $this->num = $num;

        return $this;
    }

    /**
     * Get num
     *
     * @return integer
     */
    public function getNum()
    {
        return $this->num;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     *
     * @return vente
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set remarque
     *
     * @param string $remarque
     *
     * @return vente
     */
    public function setRemarque($remarque)
    {
        $this->remarque = $remarque;

        return $this;
    }

    /**
     * Get remarque
     *
     * @return string
     */
    public function getRemarque()
    {
        return $this->remarque;
    }

    /**
     * Set total
     *
     * @param float $total
     *
     * @return vente
     */
    public function setTotal($total)
    {
        $this->total = $total;

        return $this;
    }

    /**
     * Get total
     *
     * @return float
     */
    public function getTotal()
    {
        return $this->total;
    }

    /**
     * Set avance
     *
     * @param float $avance
     *
     * @return vente
     */
    public function setAvance($avance)
    {
        $this->avance = $avance;

        return $this;
    }

    /**
     * Get avance
     *
     * @return float
     */
    public function getAvance()
    {
        return $this->avance;
    }

    /**
     * Set client
     *
     * @param \Istok\IstokBundle\Entity\client $client
     *
     * @return vente
     */
    public function setClient(\Istok\IstokBundle\Entity\client $client = null)
    {
        $this->client = $client;

        return $this;
    }

    /**
     * Get client
     *
     * @return \Istok\IstokBundle\Entity\client
     */
    public function getClient()
    {
        return $this->client;
    }

    /**
     * Set facilite
     *
     * @param \Istok\IstokBundle\Entity\facilite $facilite
     *
     * @return vente
     */
    public function setFacilite(\Istok\IstokBundle\Entity\facilite $facilite = null)
    {
        $this->facilite = $facilite;

        return $this;
    }

    /**
     * Get facilite
     *
     * @return \Istok\IstokBundle\Entity\facilite
     */
    public function getFacilite()
    {
        return $this->facilite;
    }

    /**
     * Set isavance
     *
     * @param integer $isavance
     *
     * @return vente
     */
    public function setIsavance($isavance)
    {
        $this->isavance = $isavance;

        return $this;
    }

    /**
     * Get isavance
     *
     * @return integer
     */
    public function getIsavance()
    {
        return $this->isavance;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return vente
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }

    /**
     * Set type
     *
     * @param integer $type
     *
     * @return vente
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return integer
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set user
     *
     * @param \User\UserBundle\Entity\user $user
     *
     * @return vente
     */
    public function setUser(\User\UserBundle\Entity\user $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \User\UserBundle\Entity\user
     */
    public function getUser()
    {
        return $this->user;
    }
}
