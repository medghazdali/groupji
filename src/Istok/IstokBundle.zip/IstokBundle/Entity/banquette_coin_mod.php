<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * banquette_coin_mod
 *
 * @ORM\Table(name="banquette_coin_mod")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\banquette_coin_modRepository")
 */
class banquette_coin_mod
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @var float
     *
     * @ORM\Column(name="metrage", type="float")
     */
    private $metrage;



    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;
    


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set metrage
     *
     * @param float $metrage
     *
     * @return banquette_coin_mod
     */
    public function setMetrage($metrage)
    {
        $this->metrage = $metrage;

        return $this;
    }

    /**
     * Get metrage
     *
     * @return float
     */
    public function getMetrage()
    {
        return $this->metrage;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return banquette_coin_mod
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }
}
