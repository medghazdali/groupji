<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * sous_banquettes
 *
 * @ORM\Table(name="sous_banquettes")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\sous_banquettesRepository")
 */
class sous_banquettes
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="sous_categorie", type="string", length=50)
     */
    private $sous_categorie;


    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;

    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\cat_banquettes")
    *@ORM\JoinColumn(name="cat_banquettes_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $cat_banquettes;
   


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set sousCategorie
     *
     * @param string $sousCategorie
     *
     * @return sous_banquettes
     */
    public function setSousCategorie($sousCategorie)
    {
        $this->sous_categorie = $sousCategorie;

        return $this;
    }

    /**
     * Get sousCategorie
     *
     * @return string
     */
    public function getSousCategorie()
    {
        return $this->sous_categorie;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return sous_banquettes
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }

    /**
     * Set catBanquettes
     *
     * @param \Istok\IstokBundle\Entity\cat_banquettes $catBanquettes
     *
     * @return sous_banquettes
     */
    public function setCatBanquettes(\Istok\IstokBundle\Entity\cat_banquettes $catBanquettes = null)
    {
        $this->cat_banquettes = $catBanquettes;

        return $this;
    }

    /**
     * Get catBanquettes
     *
     * @return \Istok\IstokBundle\Entity\cat_banquettes
     */
    public function getCatBanquettes()
    {
        return $this->cat_banquettes;
    }
}
