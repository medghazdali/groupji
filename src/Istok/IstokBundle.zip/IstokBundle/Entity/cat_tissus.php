<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * cat_tissus
 *
 * @ORM\Table(name="cat_tissus")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\cat_tissusRepository")
 */
class cat_tissus
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="categorie", type="string", length=50)
     */
    private $categorie;


    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;
   



  

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set categorie
     *
     * @param string $categorie
     *
     * @return cat_tissus
     */
    public function setCategorie($categorie)
    {
        $this->categorie = $categorie;

        return $this;
    }

    /**
     * Get categorie
     *
     * @return string
     */
    public function getCategorie()
    {
        return $this->categorie;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return cat_tissus
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }
}
