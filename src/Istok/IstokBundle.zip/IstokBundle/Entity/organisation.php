<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * organisation
 *
 * @ORM\Table(name="organisation")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\organisationRepository")
 */
class organisation
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=50)
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=50)
     */
    private $email;


    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;
    
    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return organisation
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return organisation
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return organisation
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return organisation
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }
}
