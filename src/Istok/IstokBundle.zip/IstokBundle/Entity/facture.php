<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * facture
 *
 * @ORM\Table(name="facture")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\factureRepository")
 */
class facture
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="reference", type="string", length=65)
     */
    private $reference;


    /**
     * @var \DateTime
     *
     * @ORM\Column(name="datestock", type="datetime")
     */
    private $datestock;

    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;

    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\vente")
    *@ORM\JoinColumn(name="vente_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $vente;


    /**
    *@ORM\ManyToOne(targetEntity="\User\UserBundle\Entity\user")
    *@ORM\JoinColumn(name="user_id",referencedColumnName="id")
    */
    private $user;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set reference
     *
     * @param string $reference
     *
     * @return facture
     */
    public function setReference($reference)
    {
        $this->reference = $reference;

        return $this;
    }

    /**
     * Get reference
     *
     * @return string
     */
    public function getReference()
    {
        return $this->reference;
    }

    /**
     * Set total
     *
     * @param float $total
     *
     * @return facture
     */
    public function setTotal($total)
    {
        $this->total = $total;

        return $this;
    }

    /**
     * Get total
     *
     * @return float
     */
    public function getTotal()
    {
        return $this->total;
    }

    /**
     * Set datestock
     *
     * @param \DateTime $datestock
     *
     * @return facture
     */
    public function setDatestock($datestock)
    {
        $this->datestock = $datestock;

        return $this;
    }

    /**
     * Get datestock
     *
     * @return \DateTime
     */
    public function getDatestock()
    {
        return $this->datestock;
    }

    /**
     * Set vente
     *
     * @param \Istok\IstokBundle\Entity\vente $vente
     *
     * @return facture
     */
    public function setVente(\Istok\IstokBundle\Entity\vente $vente = null)
    {
        $this->vente = $vente;

        return $this;
    }

    /**
     * Get vente
     *
     * @return \Istok\IstokBundle\Entity\vente
     */
    public function getVente()
    {
        return $this->vente;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return facture
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }

    /**
     * Set user
     *
     * @param \User\UserBundle\Entity\user $user
     *
     * @return facture
     */
    public function setUser(\User\UserBundle\Entity\user $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \User\UserBundle\Entity\user
     */
    public function getUser()
    {
        return $this->user;
    }
}
