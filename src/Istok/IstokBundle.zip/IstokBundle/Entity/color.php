<?php

namespace Istok\IstokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * color
 *
 * @ORM\Table(name="color")
 * @ORM\Entity(repositoryClass="Istok\IstokBundle\Repository\colorRepository")
 */
class color
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="couleur", type="string", length=65)
     */
    private $couleur;
 
    /**
    *@ORM\ManyToOne(targetEntity="\Istok\IstokBundle\Entity\etab")
    *@ORM\JoinColumn(name="etab_id",referencedColumnName="id", onDelete="CASCADE")
    */
    private $etab;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set couleur
     *
     * @param string $couleur
     *
     * @return color
     */
    public function setCouleur($couleur)
    {
        $this->couleur = $couleur;

        return $this;
    }

    /**
     * Get couleur
     *
     * @return string
     */
    public function getCouleur()
    {
        return $this->couleur;
    }

    /**
     * Set etab
     *
     * @param \Istok\IstokBundle\Entity\etab $etab
     *
     * @return color
     */
    public function setEtab(\Istok\IstokBundle\Entity\etab $etab = null)
    {
        $this->etab = $etab;

        return $this;
    }

    /**
     * Get etab
     *
     * @return \Istok\IstokBundle\Entity\etab
     */
    public function getEtab()
    {
        return $this->etab;
    }
}
