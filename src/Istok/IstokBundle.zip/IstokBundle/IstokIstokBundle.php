<?php

namespace Istok\IstokBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IstokIstokBundle extends Bundle
{
}
