<?php

namespace GJI\GJIBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

use GJI\GJIBundle\Entity\Groupe;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Validator\Constraints\DateTime;

class MainController extends Controller
{


    public function indexAction()
    {

        $em=$this->getDoctrine()->getManager();
        $user=$this->container->get('security.token_storage')->getToken()->getUser(); 

        $setParameter = [];
        $setParameter['user'] = $user->getid();

        $QB = $em->createQueryBuilder();
        $QB->select('gu');
        $QB->from('GJIBundle:Groupe_User', 'gu');
        $QB->innerJoin('gu.Groupe', 'g');
        $QB->innerJoin('gu.User', 'u');
        $QB->innerJoin('gu.UserP', 'up');
        $QB->where('u.id=:user');
        $QB->orwhere('up.id=:user');
        $QB->orderBy('gu.id', 'DESC');
        $QB->groupBy('g.id');

        $QB->setParameters($setParameter);
        $Q = $QB->getQuery();
        $List = $Q->execute();

        $datas=[];

        foreach ($List as $value) {

            $data=[];

            $groupe =$value->getGroupe();
            $User =$value->getUser();
            $userParticipant=$value->getUserP();

            $id=$groupe->getid();
            $title=$groupe->gettitle();
            $enabled=$groupe->getenabled();
            $body=$groupe->getbody();
            $Cat=$groupe->getCat()->getcategorie();
            $dateCreation=$groupe->getdateCreation()->format('d-m-Y H:i:s');           
            $file=$groupe->getpath();
            $UserName =$User->getusername();

            $myGroupe=0;
            if($userParticipant->getid()==$User->getid())
                $myGroupe=1;

            $UserName =$User->getusername();
            $UserId =$User->getid();

            $data['id']=$id;
            $data['groupe_UserId']=$value->getid();
            $data['title']=$title;
            $data['enabled']=$enabled;
            $data['body']=$body;
            $data['Cat']=$Cat;
            $data['dateCreation']=$dateCreation;
            $data['file']=$file;
            $data['UserName']=$UserName;
            $data['myGroupe']=$myGroupe;
            $data['UserName']=$User->getFname().' '.$User->getLname();
            $data['UserId']=$UserId;
            $data['refgroup']=$groupe->getrefgroup();
 

            array_push($datas, $data);


        }
        
        // var_dump($datas);

        return $this->render('GJIBundle:Dash:index.html.twig', array('datas' => $datas ));
    }



    public function MyGroupsAction()
    {

        $em=$this->getDoctrine()->getManager();
        $user=$this->container->get('security.token_storage')->getToken()->getUser(); 

        $setParameter = [];
        $setParameter['user'] = $user->getid();

        $QB = $em->createQueryBuilder();
        $QB->select('gu');
        $QB->from('GJIBundle:Groupe_User', 'gu');
        $QB->innerJoin('gu.Groupe', 'g');
        $QB->innerJoin('gu.UserP', 'up');
        $QB->orwhere('up.id=:user');
        $QB->orderBy('gu.id', 'DESC');
        $QB->groupBy('g.id');

        $QB->setParameters($setParameter);
        $Q = $QB->getQuery();
        $List = $Q->execute();

        $datas=[];

        foreach ($List as $value) {

            $data=[];

            $groupe =$value->getGroupe();
            $User =$value->getUser();
            $userParticipant=$value->getUserP();

            $id=$groupe->getid();
            $title=$groupe->gettitle();
            $enabled=$groupe->getenabled();
            $body=$groupe->getbody();
            $Cat=$groupe->getCat()->getcategorie();
            $dateCreation=$groupe->getdateCreation()->format('d-m-Y H:i');           
            $file=$groupe->getpath();
            $UserName =$User->getusername();

            $myGroupe=0;
            if($userParticipant->getid()==$User->getid())
                $myGroupe=1;

            $UserName =$User->getusername();
            $UserId =$User->getid();



            $data['groupe_UserId']=$value->getid();
            $data['id']=$id;
            $data['title']=$title;
            $data['enabled']=$enabled;
            $data['body']=$body;
            $data['Cat']=$Cat;
            $data['dateCreation']=$dateCreation;
            $data['file']=$file;
            $data['UserName']=$UserName;
            $data['myGroupe']=$myGroupe;
            $data['UserName']=$User->getFname().' '.$User->getLname();
            $data['UserId']=$UserId;
             $data['refgroup']=$groupe->getrefgroup();


            array_push($datas, $data);


        }
        
        // var_dump($datas);

        return $this->render('GJIBundle:Dash:index.html.twig', array('datas' => $datas ));
    }




    public  function get_identity()
    {
        $em=$this->getDoctrine()->getManager();
        $user=$this->container->get('security.token_storage')->getToken()->getUser();
        return $user;
    }

    public  function check_user($id)
    {

        //$etab=$this->get_identity()->getuser();
        $idetab=$this->get_identity()->getid();

        if($id==$idetab)
            return 1;
        else
            return 0;    
    }





   public function InviteFriendAction($id,Request $request)
    {

        $em=$this->getDoctrine()->getManager();
        $Group = $em->getRepository('GJIBundle:Groupe')->find($id);
        $title=$Group->gettitle();

        $user=$this->container->get('security.token_storage')->getToken()->getUser(); 
        $getId=$user->getId();
        $nameUser=$user->getFname()." ".$user->getLname();
        $refgroup=$Group->getrefgroup();




        return $this->render('GJIBundle:Invite:invite.html.twig', array('user'=>$getId,'title'=>$title,'refgroup'=>$refgroup,'nameUser'=>$nameUser));

    }



   public function ManagerUsersAction($id,Request $request)
    {

        $em=$this->getDoctrine()->getManager();
        $MemberGroups = $em->getRepository('GJIBundle:MemberGroup')->findBy(array('Groupe'=>$id));

        $Group = $em->getRepository('GJIBundle:Groupe')->find($id);
        $title=$Group->gettitle();


        $datas=[];
        foreach ($MemberGroups as $key => $MemberGroup) {

            $user=$MemberGroup->getUser();
            $data['id']=$MemberGroup->getid();
            $data['name']=$user->getFname().' '.$user->getLname();
            $data['tel']=$user->getusername();
            $data['email']=$user->getemail();
            $data['previlige']=$MemberGroup->getprevilige();
            $data['active']=$MemberGroup->getactive();
            array_push($datas, $data);

        }


        return $this->render('GJIBundle:Manager:index.html.twig', array('datas'=>$datas,'title'=>$title));

    }

 



   public function EditActiveAction(Request $request)
    {

        $em=$this->getDoctrine()->getManager();

        $id = $request->get('id');        
        $actif = $request->get('actif');        

        $MemberGroup = $em->getRepository('GJIBundle:MemberGroup')->find($id);
        // var_dump($MemberGroup);
        $MemberGroup->setactive($actif);
        
        $em->persist($MemberGroup);       
        $em->flush(); 


        return new Response(0);

    }


   public function EditPreviligeAction(Request $request)
    {

        $em=$this->getDoctrine()->getManager();

        $id = $request->get('id');        
        $previlige = $request->get('previlige');        

        $MemberGroup = $em->getRepository('GJIBundle:MemberGroup')->find($id);


        $MemberGroup->setprevilige($previlige);
        
        $em->persist($MemberGroup);       
        $em->flush(); 


        return new Response(0);

    }




}
