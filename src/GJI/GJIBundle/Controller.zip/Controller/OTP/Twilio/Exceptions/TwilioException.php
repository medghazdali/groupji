<?php


namespace GJI\GJIBundle\Controller\OTP\Twilio\Exceptions;


class TwilioException extends \Exception {

}