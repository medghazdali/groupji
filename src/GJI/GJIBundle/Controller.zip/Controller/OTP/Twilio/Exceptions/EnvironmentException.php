<?php


namespace GJI\GJIBundle\Controller\OTP\Twilio\Exceptions;


class EnvironmentException extends TwilioException {

}